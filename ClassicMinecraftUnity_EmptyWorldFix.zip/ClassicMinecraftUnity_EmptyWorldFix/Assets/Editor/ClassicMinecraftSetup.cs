using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

[InitializeOnLoad]
public static class ClassicMinecraftSetup
{
    private const string Root = "Assets/ClassicMinecraftGenerated";
    private const string PrefabFolder = Root + "/Prefabs";
    private const string MaterialFolder = Root + "/Materials";
    private const string SceneFolder = "Assets/Scenes";
    private const string ScenePath = SceneFolder + "/ClassicMinecraft.unity";

    // Automatically creates the starter scene the first time the project imports these scripts.
    static ClassicMinecraftSetup()
    {
        EditorApplication.delayCall += AutoCreateIfMissing;
    }

    private static void AutoCreateIfMissing()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode) return;

        if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) == null)
        {
            Debug.Log("Classic Minecraft: no starter scene found. Creating it automatically...");
            BuildScene();
        }
    }

    [MenuItem("Classic Minecraft/Build or Rebuild Starter Scene")]
    public static void BuildScene()
    {
        EnsureFolder("Assets", "ClassicMinecraftGenerated");
        EnsureFolder(Root, "Prefabs");
        EnsureFolder(Root, "Materials");
        EnsureFolder("Assets", "Scenes");

        GameObject grass = MakeBlockPrefab("Grass", BlockType.Grass, new Color(0.30f, 0.62f, 0.22f));
        GameObject dirt = MakeBlockPrefab("Dirt", BlockType.Dirt, new Color(0.43f, 0.27f, 0.15f));
        GameObject stone = MakeBlockPrefab("Stone", BlockType.Stone, new Color(0.48f, 0.49f, 0.50f));
        GameObject sand = MakeBlockPrefab("Sand", BlockType.Sand, new Color(0.82f, 0.75f, 0.48f));

        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

        GameObject world = new GameObject("World");
        WorldGenerator generator = world.AddComponent<WorldGenerator>();
        generator.worldWidth = 32;
        generator.worldDepth = 32;
        generator.baseHeight = 7;
        generator.heightVariation = 4;
        generator.noiseScale = 0.08f;
        generator.grassBlock = grass;
        generator.dirtBlock = dirt;
        generator.stoneBlock = stone;
        generator.sandBlock = sand;

        GameObject player = new GameObject("Player");
        player.transform.position = new Vector3(16f, 18f, 16f);

        CharacterController character = player.AddComponent<CharacterController>();
        character.height = 1.8f;
        character.radius = 0.38f;
        character.center = new Vector3(0f, 0.9f, 0f);
        character.stepOffset = 0.35f;
        character.slopeLimit = 45f;

        GameObject cameraObject = new GameObject("Player Camera");
        cameraObject.tag = "MainCamera";
        cameraObject.transform.SetParent(player.transform);
        cameraObject.transform.localPosition = new Vector3(0f, 1.6f, 0f);
        Camera camera = cameraObject.AddComponent<Camera>();
        camera.fieldOfView = 75f;
        camera.nearClipPlane = 0.05f;
        cameraObject.AddComponent<AudioListener>();

        FirstPersonController movement = player.AddComponent<FirstPersonController>();
        movement.cameraTransform = cameraObject.transform;

        BlockInteraction interaction = player.AddComponent<BlockInteraction>();
        interaction.playerCamera = camera;
        interaction.blockToPlace = dirt;

        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(0.62f, 0.66f, 0.72f);
        RenderSettings.ambientIntensity = 1f;

        EditorSceneManager.SaveScene(scene, ScenePath);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Selection.activeGameObject = player;

        EditorUtility.DisplayDialog(
            "Classic Minecraft Ready",
            "The starter scene has been created. The terrain appears when you press Play. Open Assets/Scenes/ClassicMinecraft.unity if needed.",
            "OK");
    }

    private static GameObject MakeBlockPrefab(string name, BlockType type, Color color)
    {
        string materialPath = MaterialFolder + "/" + name + ".mat";
        Material material = AssetDatabase.LoadAssetAtPath<Material>(materialPath);
        if (material == null)
        {
            Shader shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) shader = Shader.Find("Standard");
            material = new Material(shader);
            material.color = color;
            AssetDatabase.CreateAsset(material, materialPath);
        }
        else
        {
            material.color = color;
            EditorUtility.SetDirty(material);
        }

        GameObject temporary = GameObject.CreatePrimitive(PrimitiveType.Cube);
        temporary.name = name;
        temporary.GetComponent<Renderer>().sharedMaterial = material;
        Block block = temporary.AddComponent<Block>();
        block.blockType = type;

        string prefabPath = PrefabFolder + "/" + name + ".prefab";
        GameObject prefab = PrefabUtility.SaveAsPrefabAsset(temporary, prefabPath);
        Object.DestroyImmediate(temporary);
        return prefab;
    }

    private static void EnsureFolder(string parent, string child)
    {
        string path = parent + "/" + child;
        if (!AssetDatabase.IsValidFolder(path))
            AssetDatabase.CreateFolder(parent, child);
    }
}
