public enum BlockType
{
    Grass,
    Dirt,
    Stone,
    Wood,
    Leaves,
    Sand
}
