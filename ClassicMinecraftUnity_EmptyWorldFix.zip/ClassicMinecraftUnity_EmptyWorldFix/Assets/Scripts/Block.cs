using UnityEngine;

public class Block : MonoBehaviour
{
    public BlockType blockType;
}
