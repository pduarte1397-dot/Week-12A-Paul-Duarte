using UnityEngine;

public class BlockInteraction : MonoBehaviour
{
    public Camera playerCamera;
    public float reach = 6f;
    public GameObject blockToPlace;
    public LayerMask blockLayer = ~0;

    private void Update()
    {
        if (playerCamera == null || Cursor.lockState != CursorLockMode.Locked)
            return;

        if (Input.GetMouseButtonDown(0))
            BreakBlock();

        if (Input.GetMouseButtonDown(1))
            PlaceBlock();
    }

    private void BreakBlock()
    {
        if (Physics.Raycast(playerCamera.transform.position, playerCamera.transform.forward,
            out RaycastHit hit, reach, blockLayer))
        {
            if (hit.collider.GetComponent<Block>() != null)
                Destroy(hit.collider.gameObject);
        }
    }

    private void PlaceBlock()
    {
        if (blockToPlace == null) return;

        if (Physics.Raycast(playerCamera.transform.position, playerCamera.transform.forward,
            out RaycastHit hit, reach, blockLayer))
        {
            Vector3 position = hit.collider.transform.position + hit.normal;
            position = new Vector3(Mathf.Round(position.x), Mathf.Round(position.y), Mathf.Round(position.z));

            Collider playerCollider = GetComponent<Collider>();
            if (playerCollider != null)
            {
                Bounds newBlockBounds = new Bounds(position, Vector3.one);
                if (playerCollider.bounds.Intersects(newBlockBounds))
                    return;
            }

            Instantiate(blockToPlace, position, Quaternion.identity);
        }
    }
}
