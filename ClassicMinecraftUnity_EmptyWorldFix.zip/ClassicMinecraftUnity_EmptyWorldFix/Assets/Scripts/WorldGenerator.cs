using UnityEngine;

public class WorldGenerator : MonoBehaviour
{
    [Header("World Settings")]
    public int worldWidth = 48;
    public int worldDepth = 48;
    public int baseHeight = 8;
    public int heightVariation = 5;
    public float noiseScale = 0.07f;

    [Header("Block Prefabs")]
    public GameObject grassBlock;
    public GameObject dirtBlock;
    public GameObject stoneBlock;
    public GameObject sandBlock;

    private bool generated;

    private void Start()
    {
        GenerateWorld();
    }

    [ContextMenu("Generate World Now")]
    public void GenerateWorld()
    {
        if (generated) return;
        if (grassBlock == null || dirtBlock == null || stoneBlock == null || sandBlock == null)
        {
            Debug.LogError("WorldGenerator: Assign all four block prefabs in the Inspector.", this);
            return;
        }

        generated = true;

        for (int x = 0; x < worldWidth; x++)
        {
            for (int z = 0; z < worldDepth; z++)
            {
                float noise = Mathf.PerlinNoise(x * noiseScale, z * noiseScale);
                int surface = baseHeight + Mathf.RoundToInt(noise * heightVariation);

                for (int y = 0; y <= surface; y++)
                {
                    GameObject prefab;
                    if (y == surface)
                        prefab = noise < 0.27f ? sandBlock : grassBlock;
                    else if (y >= surface - 3)
                        prefab = dirtBlock;
                    else
                        prefab = stoneBlock;

                    Instantiate(prefab, new Vector3(x, y, z), Quaternion.identity, transform);
                }
            }
        }

        Debug.Log("Classic Minecraft world generated.");
    }
}
